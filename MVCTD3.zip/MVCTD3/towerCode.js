//Tower information

var towerLists = {
    basic: {type: "basic", 
        image: initImage("towers/Normal.png"), 
        speed:60, 
        damage: 1, 
        range: 250, 
        baseCost: 150, 
        specialCosts: [500, 1000, 2000], 
        specialUpgrades: [
            "Fires three claws at a time instead of one", 
            "Claws create a small explosion when they hit a target. Explosions deal 1 damage and can hit the original enemy too", 
            "Fires 5 claws at a time! How many claws do these cats have?", 
            "Maximum upgrades have been unlocked in this path"]
        }, 
    music: {type: "music", 
        image: initImage("towers/music.png"), 
        speed:120, 
        damage: 1, 
        range: 125, 
        baseCost: 300, 
        specialCosts: [1000, 2000, 3500],
        specialUpgrades: [
            "Incresese claw amount to 12", 
            "Increases claw amount to 16!", 
            "Claws create a small explosion when they hit a target. Explosions deal 1 damage and can hit the original enemy too", 
            "Maximum upgrades have been unlocked in this path"]
        }, 
    super: {type: "super", 
        image: initImage("towers/super.png"), 
        speed:12, 
        damage: 1, 
        range: 300, 
        baseCost: 1000, 
        specialCosts: [3000, 4000, 10000], 
        specialUpgrades: [
            "Fires three claws at a time instead of one", 
            "Claws create a small explosion when they hit a target. Explosions deal 1 damage and can hit the original enemy too", 
            "Fires 5 claws at a time! How many claws do these cats have?", 
            "Maximum upgrades have been unlocked in this path"]
    }, 
    boat: {type: "boat", 
        image: initImage("towers/boat.png"), 
        speed:60, 
        damage: 1, 
        range: 200, 
        baseCost: 400, 
        specialCosts: [250, 500, 750], 
        specialUpgrades: [
            "Utilises the second cannon to fire a claw directly backwards from the target", 
            "Claws create a small explosion when they hit a target. Explosions deal 1 damage and can hit the original enemy too", 
            "Gains a minigun to deal 1 extra damage to the target every attack", 
            "Maximum upgrades have been unlocked in this path"]
        },
    farm: {type: "farm", 
        image: initImage("towers/farm.png"), 
        speed:60, 
        damage: 1, 
        range: 2000, 
        baseCost: 1000, 
        specialCosts: [1000, 3000, 5000], 
        specialUpgrades: [
            "Makes you a free 50 dollars at the end of the round, no matter the other upgrades.", 
            "Automatically collects the drops for you.", 
            "Every other Farm gains 5 dollars per drop (equivalent to 1 damage upgrade). Can stack additively.", 
            "Maximum upgrades have been unlocked in this path"]
        },
    fire: {type: "fire", 
        image: initImage("towers/fire.png"), 
        speed:90, 
        damage: 1, 
        range: 250, 
        baseCost: 600, 
        specialCosts: [1200, 2400, 3000], 
        specialUpgrades: [
            "Fire slows down attacked enemies by 10 percent.", 
            "The fire now explodes when hitting an enemy.", 
            "ANy enemy hit by the explosion now is also set on fire for the one damage, but for a shorter time.", 
            "Maximum upgrades have been unlocked in this path"]
        }
    };
var towerArray = [];
function checkForTargetedEnemy(towerX, towerY, targetPriority, range){
    var out = null; 
    var tPx = towerX * 62.5 + 31.25;
    var tPy = towerY * 62.5 + 31.25;
    
    var maxDistance = -1; // Track the highest progress score seen so far

    for(var i = 0; i < enemyStats.length; i++){
        var enemy = enemyStats[i];
        
        // Check if this enemy is within the tower's shooting radius
        if(findDist(tPx, tPy, enemy.x, enemy.y) <= range){
            
            // "First" targeting: Pick the enemy that has traveled the most total distance
            if(targetPriority === "first") {
                if(enemy.distanceTraveled > maxDistance) {
                    maxDistance = enemy.distanceTraveled;
                    out = i; // Save this enemy's index as the current prime target
                }
            }
        }
    }
    return out;
}
//Allows tower to target enemies
function findTargetToFireAt(targetPriority, towerPixelX, towerPixelY, enemyID){
    var enemy = enemyStats[enemyID];
    if(enemy != undefined){
        var offsetX = 0;
        var offsetY = 0;
        if(enemy.direction == Math.PI) {
            offsetX = -31.25; 
            offsetY = -31.25;
        } else if(enemy.direction == Math.PI*0.5) {
            offsetX = -31.25;
            offsetY = -31.25;
        } else if(enemy.direction == Math.PI*1.5) {
            offsetX = -31.25;
            offsetY = -31.25;
        } else if(enemy.direction == 0 || enemy.direction == Math.PI*2) {
            offsetX = 125;
            offsetY = 62.5;
        }

        return getAngleToTarget(
            towerPixelX, 
            towerPixelY, 
            enemy.x + offsetX, 
            enemy.y + offsetY
        );
    } else {
        return null;
    }
}

//Update tower info
//Also why is the projectile spawning so long!!
function updateTowerStats(){
    //For each tower:
    for(var i = 0; i < towerArray.length; i++){
        //Get info
        var tower = towerArray[i];
        for(var j=0; j<tower.effects.length; j++){
            tower.effects[j].length--;
            if(tower.effects[j].length == 0){tower.effects.splice(j,1);}
        }
        var target;
        //Check if is farm, and then dont rotate if that is the answer
        if(tower.type == towerLists.farm){
            target = 1;
            tower.direction = 0;
        }
        //Draw tower
        drawImg(tower.type.image, tower.x * 62.5+31.25, tower.y * 62.5+31.25, 62.5, 62.5, tower.direction);
        if (tower.reloadTime > 0) {
            tower.reloadTime--;
        }
        
        var targetedEnemy = null;
        if(enemyStats && enemyStats.length > 0){
            targetedEnemy = checkForTargetedEnemy(tower.x, tower.y, "first", (tower.type.range *1.25 ** tower.level[1]));
        }
        if(targetedEnemy === null || targetedEnemy === undefined) {
            if(tower.reloadTime <= 0) {
                tower.reloadTime = 1;
            }
            continue;
        }
        var towerPixelX = tower.x * 62.5;
        var towerPixelY = tower.y * 62.5;
        if(tower.type != towerLists.farm){
        target = findTargetToFireAt("first", towerPixelX, towerPixelY, targetedEnemy);}
        //Make shorter ASAP, as is too long
        if(target !== null){
            tower.direction = target;
            if(tower.type == towerLists.boat){
                tower.direction += 0.5*Math.PI;
            }
            if(tower.reloadTime <= 0){
                tower.reloadTime = tower.type.speed*0.8**tower.level[0];
                for(var k=0; k<tower.effects.length; k++){
                    if(tower.effects[k].effect.speed){
                    tower.reloadTime *= tower.effects[k].effect.speed;}
                }
                if(tower.type == towerLists.music){
                    if(tower.level[3] == 0){
                        for(var l=0; l<8; l++){
                        createProjectile(tower.x+0.5, tower.y+0.5, 0.25*Math.PI*l, "Normal", "t00", tower.level[2]+1);}
                    }
                    else if(tower.level[3] == 1){
                        for(var m=0; m<12; m++){
                            createProjectile(tower.x+0.5, tower.y+0.5, 1/6*Math.PI*m, "Normal", "t00", tower.level[2]+1);}
                        }
                    else if(tower.level[3] == 2){
                        for(var n=0; n<16; n++){
                            createProjectile(tower.x+0.5, tower.y+0.5, 0.125*Math.PI*n, "Normal", "t00", tower.level[2]+1);}
                        }
                    else if(tower.level[3] == 3){
                        for(var o=0; o<16; o++){
                            createProjectile(tower.x+0.5, tower.y+0.5, 0.125*Math.PI*o, "Normal", "t00", tower.level[2]+1, true);}
                        }

                }
                else if(tower.type == towerLists.basic){
                    if(tower.level[3] == 0){
                        createProjectile(tower.x+0.5, tower.y+0.5, tower.direction, "Normal", "t00", tower.level[2]+1);
                    }
                    else if(tower.level[3] == 1){
                        for(var p=0; p<3; p++){
                            createProjectile(tower.x+0.5, tower.y+0.5, -0.1+tower.direction+0.1*p, "Normal", "t00", tower.level[2]+1);}
                        }
                    else if(tower.level[3] == 2){
                        for(var q=0; q<3; q++){
                            createProjectile(tower.x+0.5, tower.y+0.5, -0.1+tower.direction+0.1*q, "Normal", "t00", tower.level[2]+1, true);}
                        }
                    else if(tower.level[3] == 3){
                        for(var r=0; r<5; r++){
                            createProjectile(tower.x+0.5, tower.y+0.5, -0.1+tower.direction+0.05*r, "Normal", "t00", tower.level[2]+1, true);}
                        }
                }
                else if(tower.type == towerLists.boat){
                    if(tower.level[3] == 0){
                        createProjectile(tower.x+0.5, tower.y+0.5, tower.direction-0.5*Math.PI, "Normal", "t00", tower.level[2]+1);
                    }
                    else if(tower.level[3] == 1){
                        createProjectile(tower.x+0.5, tower.y+0.5, tower.direction+0.5*Math.PI, "Normal", "t00", tower.level[2]+1); 
                        createProjectile(tower.x+0.5, tower.y+0.5, tower.direction+1.5*Math.PI, "Normal", "t00", tower.level[2]+1);
                    }
                    else if(tower.level[3] == 2){
                        createProjectile(tower.x+0.5, tower.y+0.5, tower.direction+0.5*Math.PI, "Normal", "t00", tower.level[2]+1, true); 
                        createProjectile(tower.x+0.5, tower.y+0.5, tower.direction+1.5*Math.PI, "Normal", "t00", tower.level[2]+1, true);
                    }
                    else if(tower.level[3] == 3){
                        createProjectile(tower.x+0.5, tower.y+0.5, tower.direction+0.5*Math.PI, "Normal", "t00", tower.level[2]+2, true); 
                        createProjectile(tower.x+0.5, tower.y+0.5, tower.direction+1.5*Math.PI, "Normal", "t00", tower.level[2]+1, true);
                    }
                }
                else if(tower.type == towerLists.super){
                    if(tower.level[3] == 0){
                        createProjectile(tower.x+0.5, tower.y+0.5, tower.direction, "Normal", "t00", tower.level[2]+1);
                    }
                    else if(tower.level[3] == 1){
                        for(var s=0; s<3; s++){
                            createProjectile(tower.x+0.5, tower.y+0.5, -0.1+tower.direction+0.1*s, "Normal", "t00", tower.level[2]+1);}
                        }
                    else if(tower.level[3] == 2){
                        for(var t=0; t<3; t++){
                            createProjectile(tower.x+0.5, tower.y+0.5, -0.1+tower.direction+0.1*t, "Normal", "t00", tower.level[2]+1, true);}
                        }
                    else if(tower.level[3] == 3){
                        for(var u=0; u<5; u++){
                            createProjectile(tower.x+0.5, tower.y+0.5, -0.1+tower.direction+0.05*u, "Normal", "t00", tower.level[2]+1, true);}
                        }
                    }
                else if(tower.type == towerLists.farm){//Odd one out
                    if(tower.level[3] == 0){
                        createProjectile(tower.x+0.5, tower.y+0.5, 0, "farm", 0, (tower.level[2]+1)*5+(farmsBuffExtraMoney*5));
                    }
                    else if(tower.level[3] == 1){
                        createProjectile(tower.x+0.5, tower.y+0.5, 0, "farm", 0, (tower.level[2]+1)*5+(farmsBuffExtraMoney*5));
                    }
                    else if(tower.level[3] == 2){
                        money += (tower.level[2]+1)*5+(farmsBuffExtraMoney*5);
                    }
                    else if(tower.level[3] == 3){
                        money += (tower.level[2]+1)*5+(farmsBuffExtraMoney*5);
                    }
                }
                else if(tower.type == towerLists.fire){
                    createProjectile(tower.x+0.5, tower.y+0.5, tower.direction, "fire", "basic", tower.level[2]+1, tower.level[3]);
                }
            }
        }
    }
}

//Tower placing info
function attemptPlaceTower(){
    if(isPlacingTower){
        var location = trackInfo[placementY][placementX];
        if(location.tower == true){
            alert("There is already a tower there! Please pick another location.");
        }
        else if(location.typeTrack == grassRock){
            alert("Cannot place on top of rocks!");
        }
        else if(location.typeTrack == water || location.typeTrack == deepWater){
            if(towerBeingPlacedType == 2 && money >= 250){
                money -= 250;
                towerArray.push({
                type: towerLists.boat, 
                x:placementX, 
                y:placementY, 
                direction: Math.PI, 
                reloadTime: towerLists.boat.speed,
                level: [0,0,0,0,false],
                ID: globalTowerID++,
                effects:[]});
                isPlacingTower =  false;
            }
            else if(money < 250 && towerBeingPlacedType == 2){
                alert("Not enough money to place down! Cost is 250 btw");
            }
            else if(towerBeingPlacedType == 5){alert("Do you really think that placing the FIRE tower in WATER would go well?");}
            else{
                alert("Cannot place land type tower in water!");
            }
        }
        else if(location.track == true){
            alert("This is a road part, you cannot place here!");
        }
        else if(towerBeingPlacedType == 0 && money < 150){
            alert("Not enough money to place down! Cost is 150 btw");
        }
        else if(towerBeingPlacedType == 1 && money < 300){
            alert("Not enough money to place down! Cost is 300 btw");
        }
        else if(towerBeingPlacedType == 2 && money < 250){
            alert("Not enough money to place down! Cost is 250 btw");
        }
        else if(towerBeingPlacedType == 3 && money < 500){
            alert("Not enough money to place down! Cost is 1000 btw");
        }
        else if(towerBeingPlacedType == 4 && money < 1000){
            alert("Not enough money to place down! Cost is 1000 btw");
        }
        else if(towerBeingPlacedType == 5 && money < 600){
            alert("Not enough money to place down! Cost is 600 btw");
        }
        else{
            location.tower = true;
            if(towerBeingPlacedType == 0){
                money -= 150;
                towerArray.push({
                type: towerLists.basic, 
                x:placementX, 
                y:placementY, 
                direction: Math.PI, 
                reloadTime: towerLists.basic.speed,
                level: [0,0,0,0,false],
                ID: globalTowerID++,
                effects:[]});
                isPlacingTower =  false;
                }
            else if(towerBeingPlacedType == 4){
                money -= 1000;
                towerArray.push({
                type: towerLists.farm, 
                x:placementX, 
                y:placementY, 
                direction: 0, 
                reloadTime: towerLists.farm.speed,
                level: [0,0,0,0,false],
                ID: globalTowerID++,
                effects:[]});
                isPlacingTower =  false;
                }
            else if(towerBeingPlacedType == 1){
                money -= 300;
                towerArray.push({
                type: towerLists.music, 
                x:placementX, 
                y:placementY, 
                direction: Math.PI, 
                reloadTime: towerLists.music.speed,
                level: [0,0,0,0,false],
                ID: globalTowerID++,
                effects:[]});
                isPlacingTower =  false;
                }
            else if(towerBeingPlacedType == 2){
                alert("This is a water tower, it cannot go on the land!");
            }
            else if(towerBeingPlacedType == 3){
                money -= 1000;
                towerArray.push({
                type: towerLists["super"], 
                x:placementX, 
                y:placementY, 
                direction: Math.PI, 
                reloadTime: towerLists["super"].speed,
                level: [0,0,0,0,false],
                ID: globalTowerID++,
                effects:[]});
                isPlacingTower =  false;
            }
            else if(towerBeingPlacedType == 5){
                money -= 600;
                towerArray.push({
                type: towerLists.fire, 
                x:placementX, 
                y:placementY, 
                direction: Math.PI, 
                reloadTime: 90,
                level: [0,0,0,0,false],
                ID: globalTowerID++,
                effects:[]});
                isPlacingTower =  false;
            }
        }
    }
}

//Alerts tower information
function openStatsMenu(){
    var alertMessage = "Statistics for this tower: \n";
    alertMessage += ("Speed (how long in between firing its attack in seconds): " + (towerArray[towerOpenedID].type.speed/60)*0.8**towerArray[towerOpenedID].level[0] + "\n");
    alertMessage += ("Range (each square is 1 in this case): " + towerArray[towerOpenedID].type.range/62.5* 1.25 ** towerArray[towerOpenedID].level[1] + "\n");
    alertMessage += ("Damage (maximum): " + (towerArray[towerOpenedID].type.damage + towerArray[towerOpenedID].level[2]) + "\n");
    alertMessage += ("Special Level: " + (towerArray[towerOpenedID].level[3] + "\n"));
    alertMessage += ("Is Merged: No (will add later)");
    alert(alertMessage);
}
//Buying upgrades : Speed, Range, Damage, and Special
function attemptBuySpeedUpgrade(){
    if(towerArray[towerOpenedID].level[0] != 3 && money >= Math.floor(towerArray[towerOpenedID].type.baseCost* 1.5 ** (towerArray[towerOpenedID].level[0]+1))){
        money -= Math.floor(towerArray[towerOpenedID].type.baseCost* 1.5 ** towerArray[towerOpenedID].level[0]);
    towerArray[towerOpenedID].level[0]++;}
    else if(money < Math.floor(towerArray[towerOpenedID].type.baseCost* 1.5 ** (towerArray[towerOpenedID].level[0]+1))){alert("Not enough money: Cost is " + Math.round(Math.floor(towerArray[towerOpenedID].type.baseCost* 1.5 ** (towerArray[towerOpenedID].level[0]+1))));}
    else{alert("Max level reached!");}
    updateSidebarUI(towerArray[towerOpenedID]);
}
function attemptBuyRangeUpgrade(){
    if(towerArray[towerOpenedID].level[1] != 3 && money >= Math.floor(towerArray[towerOpenedID].type.baseCost* 1.1 ** (towerArray[towerOpenedID].level[1]+1))){
        money -= Math.floor(towerArray[towerOpenedID].type.baseCost* 1.1 ** towerArray[towerOpenedID].level[1]);
    towerArray[towerOpenedID].level[1]++;}
    else if(money < Math.floor(towerArray[towerOpenedID].type.baseCost* 1.1 ** (towerArray[towerOpenedID].level[1]+1))){alert("Not enough money: Cost is " + Math.round(Math.floor(towerArray[towerOpenedID].type.baseCost* 1.1 ** (towerArray[towerOpenedID].level[1]+1))));}
    else{alert("Max level reached!");}
    updateSidebarUI(towerArray[towerOpenedID]);
}
function attemptBuyDamageUpgrade(){
    if(towerArray[towerOpenedID].level[2] != 3 && money >= towerArray[towerOpenedID].type.baseCost* 2 ** (towerArray[towerOpenedID].level[2]+1)){
        money -= towerArray[towerOpenedID].type.baseCost* 2 ** towerArray[towerOpenedID].level[2];
    towerArray[towerOpenedID].level[2]++;}
    else if(money < towerArray[towerOpenedID].type.baseCost* 2 ** (towerArray[towerOpenedID].level[2]+1)){alert("Not enough money: Cost is " + Math.round(towerArray[towerOpenedID].type.baseCost* 2 ** (towerArray[towerOpenedID].level[2]+1)));}
    else{alert("Max level reached!");}
    updateSidebarUI(towerArray[towerOpenedID]);
}
function attemptBuySpecialUpgrade(){
    if(towerArray[towerOpenedID].level[3] != 3 && money >= towerArray[towerOpenedID].type.specialCosts[towerArray[towerOpenedID].level[3]]){
        money -= towerArray[towerOpenedID].type.specialCosts[towerArray[towerOpenedID].level[3]];
        towerArray[towerOpenedID].level[3]++;
        if(towerArray[towerOpenedID].type == towerLists.farm && towerArray[towerOpenedID].level[3] == 3){farmsBuffExtraMoney++;} else if(towerArray[towerOpenedID].type == towerLists.farm && towerArray[towerOpenedID].level[3] == 1){eorMoney++;}
    }
    else if(money < towerArray[towerOpenedID].type.specialCosts[towerArray[towerOpenedID].level[3]]){alert("Not enough money: Cost is " + towerArray[towerOpenedID].type.specialCosts[towerArray[towerOpenedID].level[3]]);}
    else{alert("Max level reached!");}
    updateSidebarUI(towerArray[towerOpenedID]);
}

//Update upgrade sidebar info
function updateSidebarUI(tower) {
    var sidebar = gebid("towerSidebar");
    gebid("specialButton").title = tower.type.specialUpgrades[tower.level[3]];
    if (sidebar) sidebar.style.display = "block";
    var speedVal = ((tower.type.speed / 60) * Math.pow(0.8, tower.level[0])).toFixed(2);
    var rangeVal = (tower.type.range / 62.5 * Math.pow(1.25, tower.level[1])).toFixed(1);
    var damageVal = tower.type.damage + tower.level[2];
    gebid("upgradeType").innerHTML = "Tower ID: " + tower.ID;
    if (gebid("sidebarTowerName")) gebid("sidebarTowerName").textContent = "Tower Type: " + tower.type.type.toUpperCase();
    if (gebid("sidebarSpeedStat")) gebid("sidebarSpeedStat").textContent = "Attack Delay: " + speedVal + "s (Lv. " + tower.level[0] + ") \n Cost is " + Math.round(towerArray[towerOpenedID].type.baseCost* 1.5 ** (towerArray[towerOpenedID].level[0]+1));
    if (gebid("sidebarRangeStat")) gebid("sidebarRangeStat").textContent = "Tile Range: " + rangeVal + " (Lv. " + tower.level[1] + ")\n Cost is " + Math.round(towerArray[towerOpenedID].type.baseCost* 1.1 ** (towerArray[towerOpenedID].level[1]+1));
    if (gebid("sidebarDamageStat")) gebid("sidebarDamageStat").textContent = "Max Damage: " + damageVal + " (Lv. " + tower.level[2] + ")\n Cost is " + Math.round(towerArray[towerOpenedID].type.baseCost* 2 ** (towerArray[towerOpenedID].level[2]+1));
    if (gebid("sidebarSpecialStat")) gebid("sidebarSpecialStat").textContent = "Special: (Lv. " + tower.level[3] + ")\n Cost is " + towerArray[towerOpenedID].type.specialCosts[towerArray[towerOpenedID].level[3]];
}
//Hide upgrade menu
function hideSidebarUI() {
    var sidebar = gebid("towerSidebar");
    if (sidebar) sidebar.style.display = "none";
}